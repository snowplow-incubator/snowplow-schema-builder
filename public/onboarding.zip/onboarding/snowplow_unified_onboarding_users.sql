{{
  config(
    materialized='incremental',
    on_schema_change='append_new_columns',
    unique_key='user_id',
    upsert_date_key='last_event_tstamp',
    sort='last_event_tstamp',
    dist='user_id',
    partition_by = snowplow_utils.get_value_by_target_type(bigquery_val = {
      "field": "last_event_tstamp",
      "data_type": "timestamp"
    }, databricks_val='last_event_tstamp_date'),
    cluster_by=snowplow_utils.get_value_by_target_type(bigquery_val=["user_id"], snowflake_val=["to_date(last_event_tstamp)"]),
    tags=["derived"],
    sql_header=snowplow_utils.set_query_tag(var('snowplow__query_tag', 'snowplow_dbt')),
    tblproperties={
      'delta.autoOptimize.optimizeWrite' : 'true',
      'delta.autoOptimize.autoCompact' : 'true'
    },
    snowplow_optimize = true
  )
}}


select *
  {% if target.type in ['databricks', 'spark'] -%}
  , DATE(last_event_tstamp) as last_event_tstamp_date
  {%- endif %}
from {{ ref('snowplow_unified_onboarding_users_this_run') }}
where {{ snowplow_utils.is_run_with_new_events('snowplow_unified') }} --returns false if run doesn't contain new events.
