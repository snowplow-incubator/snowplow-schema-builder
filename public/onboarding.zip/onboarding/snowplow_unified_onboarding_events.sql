{{
  config(
    materialized='incremental',
    on_schema_change='append_new_columns',
    unique_key='event_id',
    upsert_date_key='load_tstamp',
    sort='load_tstamp',
    dist='event_id',
    partition_by = snowplow_utils.get_value_by_target_type(bigquery_val = {
      "field": "load_tstamp",
      "data_type": "timestamp"
    }, databricks_val='load_tstamp_date'),
    cluster_by=snowplow_utils.get_value_by_target_type(bigquery_val=["event_id"], snowflake_val=["to_date(load_tstamp)"]),
    tags=["derived"],
    sql_header=snowplow_utils.set_query_tag(var('snowplow__query_tag', 'snowplow_dbt')),
    tblproperties={
      'delta.autoOptimize.optimizeWrite' : 'true',
      'delta.autoOptimize.autoCompact' : 'true'
    },
    snowplow_optimize = true
  )
}}


select *
  {% if target.type in ['databricks', 'spark'] -%}
  , DATE(load_tstamp) as load_tstamp_date
  {%- endif %}
from {{ ref('snowplow_unified_onboarding_events_this_run') }}
where {{ snowplow_utils.is_run_with_new_events('snowplow_unified') }} --returns false if run doesn't contain new events.
