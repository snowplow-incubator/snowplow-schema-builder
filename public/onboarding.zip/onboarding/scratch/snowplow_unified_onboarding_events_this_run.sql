{{
  config(
    tags=["this_run"],
  )
}}

with prep as (
  
select
  e.event_id,
  e.user_identifier,
  e.user_id,
  e.geo_country,
  e.view_id,
  e.session_identifier,
  e.derived_tstamp,
  e.load_tstamp,
  e.event_name
  
{% for field in [('success', 'boolean'), ('onboarding_stage', 'string')] %}
  
  , {{ snowplow_utils.get_field(column_name = 'unstruct_event_msc_aws_onboarding_event_1', 
                            field_name = field[0], 
                            table_alias = 'e',
                            type = field[1],
                            array_index = 0)}} as {{ field[0] }}
{% endfor %}
        
from {{ ref("snowplow_unified_events_this_run") }} as e

where event_name in ('onboarding_event')

and {{ snowplow_utils.is_run_with_new_events('snowplow_unified') }} --returns false if run doesn't contain new events.

{% if var("snowplow__ua_bot_filter", false) %}
    {{ filter_bots() }}
{% endif %}

)

select * from prep
