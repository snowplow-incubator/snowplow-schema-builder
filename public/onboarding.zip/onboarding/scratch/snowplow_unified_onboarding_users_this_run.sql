{{
  config(
    tags=["this_run"],
  )
}}

{% set fields = [('firstName', 'string'), ('lastName', 'string'), ('organizationId', 'string'), ('email', 'string'), ('jobTitle', 'string'), ('accessLevel', 'string')] %}

with prep as (
  
select
  e.user_id
  
{% for field in fields %}
  
 , {{ snowplow_utils.get_field(column_name = 'unstruct_event_user_1', 
                            field_name = field[0], 
                            table_alias = 'e',
                            type = field[1],
                            array_index = 0)}} as {{ field[0] }}
{% endfor %}

, max(collector_tstamp) as last_event_tstamp
        
from {{ ref("snowplow_unified_events_this_run") }} as e

where {{ snowplow_utils.is_run_with_new_events('snowplow_unified') }} --returns false if run doesn't contain new events.

{% if var("snowplow__ua_bot_filter", false) %}
    {{ filter_bots() }}
{% endif %}

  {{ dbt_utils.group_by(n=1+(fields|length)) }}

)

select 
  user_id,
  last_event_tstamp,
  firstName as first_name,
  lastName as last_name,
  organizationId as organization_id,
  email,
  jobTitle as job_title,
  accessLevel as access_level
  
from prep
